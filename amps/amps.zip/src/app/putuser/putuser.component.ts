import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-putuser',
  templateUrl: './putuser.component.html',
  styleUrls: ['./putuser.component.css']
})
export class PutuserComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
