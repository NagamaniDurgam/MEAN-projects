import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-postuser',
  templateUrl: './postuser.component.html',
  styleUrls: ['./postuser.component.css']
})
export class PostuserComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
