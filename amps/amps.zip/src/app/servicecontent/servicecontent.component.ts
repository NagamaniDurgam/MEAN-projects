import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-servicecontent',
  templateUrl: './servicecontent.component.html',
  styleUrls: ['./servicecontent.component.css']
})
export class ServicecontentComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
